public class SpotDistance implements Comparable<SpotDistance> {

    ParkingSpot spot;
    int distance;

    public SpotDistance(ParkingSpot s, int d) {
        this.spot = s;
        this.distance = d;
    }

    public ParkingSpot getSpot() { return spot; }

    public int compareTo(SpotDistance d) {
        return this.distance - d.distance;
    }
}