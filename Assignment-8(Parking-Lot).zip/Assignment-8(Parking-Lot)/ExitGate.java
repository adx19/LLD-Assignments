
public class ExitGate {

    Floor floor;
    BillingService billingService;

    public ExitGate(Floor floor, BillingService billingService) {
        this.floor = floor;
        this.billingService = billingService;
    }


}