import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Map;

public class BillingService {

    Map<SpotType, Double> rate;

    public BillingService(Map<SpotType, Double> rate) {
        this.rate = rate;
    }

    public double generateBill(
            ParkingTicket ticket,
            LocalDateTime outTime) {

        long hours = Duration.between(
                ticket.inTime, outTime
        ).toHours();

        return hours * rate.get(ticket.spot.type);
    }
}